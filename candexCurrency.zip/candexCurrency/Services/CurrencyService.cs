using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using System.Text.Json;
using candexCurrency.Contracts;
using candexCurrency.Models;

namespace candexCurrency.Services
{
    public class CurrencyService : ICurrencyService
    {
        private readonly HttpClient _http; // HTTP client for external API requests
        private readonly IMemoryCache _cache; // Memory cache for storing currency rates
        private static readonly HashSet<string> ValidCurrencies = new HashSet<string> { "USD", "ILS", "CAD", "GBP", "AUD", "CHF", "NOK", "PLN", "Generate server error" }; // Set of supported currencies

        public CurrencyService(IHttpClientFactory factory, IMemoryCache cache)
        {
            _http = factory.CreateClient(); // Initialize HTTP client
            _cache = cache; // Initialize memory cache
        }

        public async Task<IActionResult> GetRatesAsync(CurrencyRequest request)
        {
            if (request.Currencies == null || request.Currencies.Length == 0 || request.Currencies.Any(c => string.IsNullOrEmpty(c) || !ValidCurrencies.Contains(c)))
                return new BadRequestObjectResult(new ProblemDetails { Title = "Invalid request", Detail = "At least one valid currency is required. Supported currencies: " + string.Join(", ", ValidCurrencies) }); // Validate request currencies
            var today = DateTime.UtcNow.Date; // Get current UTC date
            var lastMonday = today.AddDays(-(int)today.DayOfWeek + (today.DayOfWeek == DayOfWeek.Sunday ? -6 : 1)); // Calculate last Monday
            var mondays = Enumerable.Range(0, 7).Select(i => lastMonday.AddDays(-7 * i)).ToList(); // Generate list of 7 Mondays
            var mondayStrings = mondays.Select(m => m.ToString("yyyy-MM-dd")).ToList(); // Convert Mondays to string format
            var cacheKey = "CurrencyRatesAll"; // Cache key for all currency rates
            if (!_cache.TryGetValue(cacheKey, out FrankfurterResponse cachedData) || cachedData?.Rates == null)
                cachedData = new FrankfurterResponse { Rates = new Dictionary<string, Dictionary<string, double>>() }; // Initialize cache if empty or null
            var currenciesToFetch = request.Currencies
                .Where(c => cachedData.Rates.Keys.Count(d => cachedData.Rates[d].ContainsKey(c)) < mondayStrings.Count)
                .Distinct()
                .ToList(); // Identify currencies missing any of the 7 Mondays
            if (currenciesToFetch.Any())
            {
                var start = mondays.Last().ToString("yyyy-MM-dd"); // Get earliest Monday
                var end = mondays.First().ToString("yyyy-MM-dd"); // Get latest Monday
                var url = $"https://api.frankfurter.app/{start}..{end}?from=EUR&to={string.Join(",", currenciesToFetch)}"; // Construct API URL
                HttpResponseMessage response;
                try
                {
                    if (currenciesToFetch.Contains("Generate server error"))
                        throw new Exception("Simulated server error"); // Simulate server error for testing
                    response = await _http.GetAsync(url); // Send request to Frankfurter API
                    response.EnsureSuccessStatusCode(); // Throw exception if request fails
                }
                catch (HttpRequestException ex)
                {
                    return new ObjectResult(new ProblemDetails { Title = "Service unavailable", Detail = $"External currency API is unavailable: {ex.Message}", Status = 503 }); // Return error if API is unavailable
                }
                var json = await response.Content.ReadAsStringAsync(); // Read API response as string
                var newData = JsonSerializer.Deserialize<FrankfurterResponse>(json); // Deserialize response to object
                if (newData == null || newData.Rates == null || newData.Rates.Count == 0)
                    return new BadRequestObjectResult(new ProblemDetails { Title = "No data", Detail = "No exchange rate data available for the selected currencies or dates." }); // Return error if no data returned
                foreach (var rate in newData.Rates)
                {
                    if (!cachedData.Rates.ContainsKey(rate.Key))
                        cachedData.Rates[rate.Key] = new Dictionary<string, double>(); // Initialize if not exists
                    foreach (var currency in rate.Value)
                        cachedData.Rates[rate.Key][currency.Key] = currency.Value; // Add or update currency rate
                }
                var expiredDates = cachedData.Rates.Keys.Where(k => !mondayStrings.Contains(k)).ToList(); // Identify outdated dates
                foreach (var date in expiredDates)
                    cachedData.Rates.Remove(date); // Remove outdated dates from cache
                _cache.Set(cacheKey, cachedData, new MemoryCacheEntryOptions { AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(6) }); // Update cache with 6-hour expiration
            }
            var result = mondays.Select(date =>
            {
                var dateStr = date.ToString("yyyy-MM-dd"); // Convert date to string
                if (!cachedData.Rates.TryGetValue(dateStr, out var rates))
                    return null; // Skip if no rates for date
                var filteredRates = request.Currencies.ToDictionary(c => c, c => rates.ContainsKey(c) ? rates[c] : 0.0); // Create rates dictionary for requested currencies
                return new CurrencyResponse { date = dateStr, rates = filteredRates }; // Create response object
            }).Where(r => r != null).ToList(); // Filter out null entries
            return new OkObjectResult(result); // Return successful response
        }
    }
}