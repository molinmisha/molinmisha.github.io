using System.Text.Json; // For JsonSerializerOptions
using candexCurrency.Contracts;
using candexCurrency.Services;

var builder = WebApplication.CreateBuilder(args); // Create web app builder

builder.Services.AddControllers().AddJsonOptions(options =>
{
    options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase; // Use camelCase for JSON serialization
});
builder.Services.AddEndpointsApiExplorer(); // Add API explorer for Swagger
builder.Services.AddSwaggerGen(); // Add Swagger generation
builder.Services.AddScoped<ICurrencyService, CurrencyService>(); // Register CurrencyService with scoped lifetime
builder.Services.AddHttpClient(); // Register IHttpClientFactory
builder.Services.AddMemoryCache(); // Register IMemoryCache

var app = builder.Build(); // Build the application

app.UseStaticFiles(); // Enable serving static files
if (app.Environment.IsDevelopment())
{
    app.UseSwagger(); // Enable Swagger in development
    app.UseSwaggerUI(); // Enable Swagger UI in development
}

app.UseHttpsRedirection(); // Enable HTTPS redirection
app.UseAuthorization(); // Enable authorization middleware
app.MapControllers(); // Map controller endpoints

app.Run(); // Run the application