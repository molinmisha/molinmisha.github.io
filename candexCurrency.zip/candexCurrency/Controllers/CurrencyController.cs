using Microsoft.AspNetCore.Mvc;
using candexCurrency; // For ICurrencyService
using candexCurrency.Models; // For CurrencyRequest
using System.Threading.Tasks;
using candexCurrency.Contracts;

namespace candexCurrency.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CurrencyController : ControllerBase
    {
        private readonly ICurrencyService _currencyService; // Currency service for handling requests

        public CurrencyController(ICurrencyService currencyService)
        {
            _currencyService = currencyService; // Initialize currency service
        }

        [HttpPost("GetRates")]
        public async Task<IActionResult> GetRates([FromBody] CurrencyRequest request)
            {
            return await _currencyService.GetRatesAsync(request); // Process request using currency service
        }
    }
}