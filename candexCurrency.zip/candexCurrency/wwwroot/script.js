const availableCurrencies = ["USD", "ILS", "CAD", "GBP", "AUD", "CHF", "NOK", "PLN", "Generate server error"]; // List of supported currencies
let isLoading = false; // Flag to track loading state
const cache = { rates: {}, expires: null }; // Local cache for currency rates

$(document).ready(function () {
    initializeApp(); // Initialize app on page load
    setupEventHandlers(); // Set up event handlers
});

function initializeApp() {
    populateCurrencySelects(); // Populate currency dropdowns
}

function populateCurrencySelects() {
    $(".currency").each(function () {
        $(this).append('<option value="">Select currency...</option>'); // Add placeholder option to each dropdown
        availableCurrencies.forEach(currency => {
            $(this).append(`<option value="${currency}">${currency}</option>`); // Add currency options to dropdown
        });
    });
}

function setupEventHandlers() {
    $("#currency-form").submit(handleFormSubmit); // Bind submit event to form
    $("#amount, .currency").on('input change', handleFieldChange); // Bind input/change events to amount and currency fields
    $("#amount").on('input', handleAmountInput); // Bind input event to amount field
    $(".currency").on('change', handleCurrencyChange); // Bind change event to currency dropdowns
}

function handleFieldChange() {
    if (!isLoading) {
        enableSubmitButton(); // Enable submit button if not loading
    }
}

function handleAmountInput() {
    const amount = parseFloat($(this).val()); // Parse input amount
    if (amount >= 0 && amount < 1000000) {
        $(this).css('border-color', '#28a745'); // Set green border for valid amount
    } else {
        $(this).css('border-color', ''); // Reset border for invalid amount
    }
}

function handleCurrencyChange() {
    updateCurrencyOptions(); // Update currency dropdown options
}

function updateCurrencyOptions() {
    const selectedCurrencies = $(".currency").map(function () {
        return $(this).val();
    }).get().filter(val => val !== ""); // Get selected currencies, excluding empty values
    $(".currency").each(function () {
        const currentValue = $(this).val(); // Get current dropdown value
        const $select = $(this); // Reference to current dropdown
        $select.find('option').each(function () {
            const optionValue = $(this).val(); // Get option value
            if (optionValue === "" || optionValue === currentValue) {
                $(this).prop('disabled', false).show(); // Enable and show placeholder or current value
            } else if (selectedCurrencies.includes(optionValue)) {
                $(this).prop('disabled', true).hide(); // Disable and hide already selected currencies
            } else {
                $(this).prop('disabled', false).show(); // Enable and show available currencies
            }
        });
    });
}

function handleFormSubmit(e) {
    e.preventDefault(); // Prevent default form submission
    hideMessages(); // Hide error messages
    if (!validateForm()) {
        return; // Exit if form validation fails
    }
    const formData = getFormData(); // Get form data
    submitRequest(formData); // Submit request with form data
}

function hideMessages() {
    $("#error-message").slideUp(300); // Hide error message with animation
}

function validateForm() {
    const amount = parseFloat($("#amount").val()); // Parse amount input
    if (isNaN(amount)) {
        showErrorMessage("Please enter a valid amount"); // Show error for invalid amount
        return false;
    }
    const currencies = $(".currency").map(function () {
        return $(this).val();
    }).get(); // Get selected currencies
    if (currencies.some(currency => !currency)) {
        showErrorMessage("Please select all three currencies"); // Show error if any currency is not selected
        return false;
    }
    if (new Set(currencies).size < 3) {
        showErrorMessage("Please choose 3 different currencies"); // Show error if currencies are not unique
        return false;
    }
    return true; // Return true if validation passes
}

function getFormData() {
    return {
        amount: parseFloat($("#amount").val()), // Get amount as float
        currencies: $(".currency").map(function () {
            return $(this).val();
        }).get() // Get array of selected currencies
    };
}

function getLastSevenMondays() {
    const today = new Date(); // Get current date
    const lastMonday = new Date(today.setDate(today.getDate() - (today.getDay() + 6) % 7)); // Calculate last Monday
    return Array.from({ length: 7 }, (_, i) => {
        const date = new Date(lastMonday); // Create new date object
        date.setDate(lastMonday.getDate() - i * 7); // Subtract weeks to get previous Mondays
        return date.toISOString().split('T')[0]; // Return date in YYYY-MM-DD format
    }); // Return dates in descending order (newest first)
}

function cleanCache() {
    const mondays = getLastSevenMondays(); // Get list of 7 Mondays
    const now = new Date().getTime(); // Get current timestamp
    if (cache.expires && now > cache.expires) {
        cache.rates = {}; // Clear rates if cache expired
        cache.expires = null; // Reset expiration
    }
    Object.keys(cache.rates).forEach(date => {
        if (!mondays.includes(date)) {
            delete cache.rates[date]; // Remove outdated dates from cache
        }
    });
}

function getMissingData(currencies) {
    const mondays = getLastSevenMondays(); // Get list of 7 Mondays
    const missing = { currencies: [], dates: mondays }; // Initialize missing data object
    currencies.forEach(currency => {
        const availableDates = Object.keys(cache.rates).filter(date => cache.rates[date].hasOwnProperty(currency)); // Get dates with data for currency
        if (availableDates.length < mondays.length) {
            missing.currencies.push(currency); // Add currency to missing list if not all dates present
        }
    });
    return missing; // Return missing currencies and dates
}

function submitRequest(formData) {
    disableSubmitButton(); // Disable submit button
    cleanCache(); // Clean outdated cache entries
    const missing = getMissingData(formData.currencies); // Get missing currencies and dates
    const requestData = missing.currencies.length ? { currencies: missing.currencies } : null; // Prepare request data if currencies are missing
    if (!requestData) {
        renderGridFromCache(formData); // Render grid from cache if no missing data
        enableSubmitButton(); // Re-enable submit button
        return;
    }
    $.ajax({
        url: "/api/currency/GetRates", // API endpoint
        method: "POST", // HTTP method
        contentType: "application/json", // Set content type to JSON
        data: JSON.stringify(requestData), // Serialize request data
        timeout: 60000, // Set request timeout to 60 seconds
        success: function (data) {
            updateCache(data); // Update cache with server data
            renderGridFromCache(formData); // Render grid with updated data
        },
        error: function (xhr, status, error) {
            handleErrorResponse(xhr, status, error); // Handle server error
        },
        complete: function () {
            enableSubmitButton(); // Re-enable submit button
        }
    });
}

function updateCache(data) {
    if (!Array.isArray(data)) return; // Exit if data is not an array
    data.forEach(row => {
        if (row.date && typeof row.date === 'string' && row.rates && typeof row.rates === 'object') { // Validate row format
            const validRates = Object.fromEntries(
                Object.entries(row.rates).filter(([_, rate]) => typeof rate === 'number' && rate >= 0)
            ); // Filter valid rates (non-negative numbers)
            if (Object.keys(validRates).length > 0) {
                cache.rates[row.date] = Object.assign(cache.rates[row.date] || {}, validRates); // Merge new rates with existing, overwriting duplicates
            }
        }
    });
    cache.expires = new Date().getTime() + 6 * 60 * 60 * 1000; // Set cache expiration to 6 hours
}

function renderGridFromCache(formData) {
    const mondays = getLastSevenMondays(); // Get list of 7 Mondays
    const amount = formData.amount; // Get amount from form
    const data = Object.keys(cache.rates)
        .filter(date => mondays.includes(date) && formData.currencies.some(currency => cache.rates[date][currency] > 0)) // Filter valid dates with non-zero rates
        .map(date => ({
            date,
            rates: formData.currencies.reduce((acc, currency) => {
                acc[currency] = cache.rates[date][currency] || 0; // Set rate or 0 if missing
                return acc;
            }, {})
        }))
        .sort((a, b) => b.date.localeCompare(a.date)); // Sort data by date in descending order (newest first)
    if (data.length === 0) {
        showErrorMessage("No valid data available for the selected currencies."); // Show error if no valid data
        $("#result").fadeOut(300); // Hide result table
        return;
    }
    renderGrid(data, formData.currencies, amount); // Render table with data
}

function handleErrorResponse(xhr, status, error) {
    let errorMessage = "Something went wrong. Please try again."; // Default error message
    if (status === 'timeout') {
        errorMessage = "Request timed out. Please check your connection and try again."; // Message for timeout error
    } else if (xhr.status === 0) {
        errorMessage = "Network error. Please check your internet connection."; // Message for network error
    } else if (xhr.responseJSON && xhr.responseJSON.message) {
        errorMessage = xhr.responseJSON.message; // Use message from server response
    }
    $("#result").fadeOut(300); // Hide result table
    showErrorMessage(errorMessage); // Show error message
}

function disableSubmitButton() {
    isLoading = true; // Set loading state
    const $btn = $("#submit-btn"); // Get submit button
    const $btnText = $btn.find(".btn-text"); // Get button text element
    $btn.prop('disabled', true); // Disable button
    $btnText.html('<span class="loading-spinner"></span>Loading...'); // Show loading spinner
}

function enableSubmitButton() {
    isLoading = false; // Clear loading state
    const $btn = $("#submit-btn"); // Get submit button
    const $btnText = $btn.find(".btn-text"); // Get button text element
    $btn.prop('disabled', false); // Enable button
    $btnText.text('Submit'); // Reset button text
}

function showErrorMessage(message) {
    $("#error-message").text(message).slideDown(300); // Display error message with animation
}

function renderGrid(data, currencies, amount) {
    const grid = $('<div class="result-grid"></div>'); // Create result grid container
    const header = $('<div class="grid-header"></div>'); // Create grid header
    header.append('<div class="grid-header-cell">Date</div>'); // Add date header cell
    currencies.forEach(c => {
        header.append(`<div class="grid-header-cell">EUR/${c}</div>`); // Add currency header cells
    });
    grid.append(header); // Append header to grid
    const body = $('<div class="grid-body"></div>'); // Create grid body
    const currencyStats = {}; // Initialize stats for min/max values
    currencies.forEach(currency => {
        const values = data.map(row => row.rates[currency] * amount).filter(val => val !== 0); // Calculate non-zero converted values
        currencyStats[currency] = {
            max: values.length ? Math.max(...values) : 0,
            min: values.length ? Math.min(...values) : 0
        }; // Store min and max for currency
    });
    data.forEach((row, rowIndex) => {
        const gridRow = $('<div class="grid-row"></div>'); // Create grid row
        const formattedDate = formatDate(row.date); // Format date for display
        gridRow.append(`<div class="grid-cell">${formattedDate}</div>`); // Add date cell
        currencies.forEach((currency, colIndex) => {
            const rate = row.rates[currency] || 0; // Get rate or 0 if missing
            const val = rate * amount; // Calculate converted value
            const formattedValue = formatCurrencyValue(val, currency); // Format value for display
            const cell = $(`<div class="grid-cell color-transition">${formattedValue}</div>`); // Create cell with transition
            if (val > 0 && val === currencyStats[currency].max) {
                cell.addClass("max"); // Mark as maximum value
            } else if (val > 0 && val === currencyStats[currency].min) {
                cell.addClass("min"); // Mark as minimum value
            }
            gridRow.append(cell); // Append cell to row
        });
        body.append(gridRow); // Append row to body
    });
    grid.append(body); // Append body to grid
    $("#result").fadeOut(300, function () {
        $(this).html(grid).fadeIn(300); // Fade out old grid and fade in new one
    });
}

function formatDate(dateString) {
    const date = new Date(dateString); // Parse date string
    const options = {
        weekday: 'short',
        month: 'short',
        day: 'numeric'
    }; // Define date format options
    return date.toLocaleDateString('en-US', options); // Return formatted date
}

function formatCurrencyValue(value, currencyCode) {
    return value.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }); // Format value as currency with 2 decimals
}