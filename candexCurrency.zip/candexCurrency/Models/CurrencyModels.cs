using System.Text.Json.Serialization;

namespace candexCurrency.Models
{
    public class CurrencyRequest
    {
        public string[] Currencies { get; set; } // Array of requested currencies
    }

    public class FrankfurterResponse
    {
        [JsonPropertyName("rates")]
        public Dictionary<string, Dictionary<string, double>>? Rates { get; set; } // Rates by date and currency
    }

    public class CurrencyResponse
    {
        public string? date { get; set; } // Date of rates
        public Dictionary<string, double>? rates { get; set; } // Currency rates for the date
    }
}