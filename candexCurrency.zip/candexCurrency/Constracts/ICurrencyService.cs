﻿
using candexCurrency.Models;
using Microsoft.AspNetCore.Mvc;

namespace candexCurrency.Contracts
{
    public interface ICurrencyService
    {
        Task<IActionResult> GetRatesAsync(CurrencyRequest request); // Interface method for getting rates
    }
}